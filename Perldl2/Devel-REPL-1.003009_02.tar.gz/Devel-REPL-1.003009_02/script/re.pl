#!/usr/bin/env perl

use Devel::REPL::Script 'run';
